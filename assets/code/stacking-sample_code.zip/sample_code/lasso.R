rm(list=ls())
library(data.table)
library(glmnet)
library(readr)

df <- read_csv('./intermediate/df-enet.csv')
df <- data.table(df)
df[,'index':=0:(nrow(df)-1)]

AICc_relative <- function(model){
    two_likelihood <- model$nulldev - deviance(model)
    k <- model$df
    n <- model$nobs
    AICc <- -two_likelihood + 2*k + 2*k*(k+1) / (n-k-1)
    return(AICc)
}

holdout_periods <- 12*20
test_start_date <- '1957-01'
test_start_idx <- df[epm_date==test_start_date,index]
test_end_idx <- nrow(df)-1
holdout_start_idx <- test_start_idx - holdout_periods
holdout_end_idx <- holdout_start_idx + holdout_periods - 1

# ==========================================================================
# Lasso for lower models
# ==========================================================================
X_variable <- c('log(DP)','log(DY)','log(DE)','log(EP)','B/M','TBL','LTY','NTIS','CPIG','LTR','SVAR','DFY','DFR','TMS','BILL','BOND','CREDIT','PPIG','IPG','VOL','MA(1,12)','MA(3,12)','MOM(6)')

lasso_pred <- c()

for (idx in holdout_start_idx:test_end_idx) {
    y_train <- df[index %in% 0:(idx-1),epm1]
    X_train <- df[index %in% 0:(idx-1),..X_variable]
    X_pred <- df[index == idx,..X_variable]

    lasso <- glmnet(x=as.matrix(X_train), y=y_train, family='gaussian', alpha=1)
    aic <- AICc_relative(lasso)
    aic_gt0 <- aic[abs(aic)>1e-6] # exclude AIC==0
    aic_idx <- which(aic==min(aic_gt0))[[1]] # adding back the index
    lambda <- lasso$lambda[aic_idx]

    lasso_pred <- append(lasso_pred, predict(lasso, newx=as.matrix(X_pred), s=lambda)[[1]])
}

write.csv(lasso_pred, './intermediate/lasso_pred.csv',row.names=FALSE)