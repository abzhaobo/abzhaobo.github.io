rm(list=ls())
library(data.table)
library(glmnet)
library(readr)

df <- read_csv('./intermediate/df-enet.csv')
df <- data.table(df)
df[,'index':=0:(nrow(df)-1)]

AICc_relative <- function(model){
    two_likelihood <- model$nulldev - deviance(model)
    k <- model$df
    n <- model$nobs
    AICc <- -two_likelihood + 2*k + 2*k*(k+1) / (n-k-1)
    return(AICc)
}

holdout_periods <- 12*20
test_start_date <- '1957-01'
test_start_idx <- df[epm_date==test_start_date,index]
test_end_idx <- nrow(df)-1
holdout_start_idx <- test_start_idx - holdout_periods
holdout_end_idx <- holdout_start_idx + holdout_periods - 1
# ==========================================================================
# C-Enet
# ==========================================================================
# Rapach and Zhou (2019), Time-Series and Cross-Sectional Stock Return Forecasting: New Machine Learning Methods, Electronic copy available at: https://ssrn.com/abstract=3428095
# Step 1: Estimate oos prediction by univariate regressions via expanding window.
# Step 2: Leave a holdout period before time t, for example, 10 years before time t. Estimate Enet on this holdout period to select the univariate models. Only keep those univariate models with non-zero Enet coefficients. Also, restrict the Enet model's coefficients to be greater than zero.
# Step 3: To make a prediction on time t, use non-zero-coefficient univariate models' predictions on time t-1, take the average.
# Step 4: Repeat Step 2 and Step 3 till the last date.

c_enet_lower_pred <- fread('./intermediate/lower_pred_12variables.csv')
X_variable <- colnames(c_enet_lower_pred)[2:length(colnames(c_enet_lower_pred))]

c_enet_pred <- c()
for (i in 0:(test_end_idx-test_start_idx)) {
    holdout_idx <- holdout_start_idx:holdout_end_idx + i
    test_idx <- test_start_idx + i
    X_train <- c_enet_lower_pred[index %in% holdout_idx, ..X_variable]
    y_train <- df[index %in% holdout_idx, epm1]
    enet <- glmnet(x=as.matrix(X_train), y=y_train, family='gaussian', alpha=0.5)
    aic <- AICc_relative(enet)
    aic_gt0 <- aic[abs(aic)>1e-6] # exclude AIC==0
    aic_idx <- which(aic==min(aic_gt0))[[1]] # get the index of the lowest AIC
    lambda <- enet$lambda[aic_idx]

    idx_lower <- summary(coef(enet, s=lambda))$i
    selected <- coef(enet, s=lambda)@Dimnames[[1]][idx_lower]
    selected <- selected[selected!='(Intercept)']
    c_enet_pred <- append(c_enet_pred,rowMeans(c_enet_lower_pred[index==test_idx,..selected]))
}

write.csv(c_enet_pred, './intermediate/c_enet_pred.csv', row.names=FALSE)