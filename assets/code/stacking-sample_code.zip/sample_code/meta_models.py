import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams['figure.figsize'] = (16.0, 9.0)

from sklearn.metrics import mean_squared_error, make_scorer
from sklearn.model_selection import GridSearchCV, TimeSeriesSplit

import statsmodels.api as sm

import lightgbm as lgb
from tqdm import tqdm

import tensorflow as tf
from tensorflow import keras

import random
import re

random_seed = 123
os.environ['PYTHONHASHSEED']=str(random_seed)
os.environ['CUDA_VISIBLE_DEVICES'] = ''
np.random.seed(random_seed)
random.seed(random_seed)
tf.random.set_seed(random_seed)
session_conf = tf.compat.v1.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
sess = tf.compat.v1.Session(graph=tf.compat.v1.get_default_graph(), config=session_conf)
tf.compat.v1.keras.backend.set_session(sess)
# ---------------------------------------------------------------------------- #
#                                     Data                                     #
# ---------------------------------------------------------------------------- #
df = pd.read_excel('./data/epm.xlsx')
regressors = np.array(df.columns[2:]).tolist()
df['epm1'] = df['epm1'].shift(-1)
df['epm_date'] = df['yyyymm'].shift(-1)
df['lag_epm1'] = df['epm1'].shift()
df['infl'] = df['infl'].shift() # inflation is lagging 2 behind epm1.
df['PPIG'] = df['PPIG'].shift()
df.rename(columns={'yyyymm':'x_date'},inplace=True)
df = df[['x_date'] + regressors + ['lag_epm1'] + ['epm_date', 'epm1']].copy()
df.dropna(inplace=True)
df['x_date'] = pd.to_datetime(df['x_date'],format='%Y%m').dt.to_period('M')
df['epm_date'] = pd.to_datetime(df['epm_date'].astype(int), format='%Y%m').dt.to_period('M')
df.rename(columns=dict(zip(df.columns[1:24].tolist(),df.columns[1:24].str.upper())),inplace=True)
df.rename(columns={'LOG(DP)':'log(DP)','LOG(DY)':'log(DY)','LOG(DE)':'log(DE)','LOG(EP)':'log(EP)'},inplace=True)
df.rename(columns={'INFL':'CPIG'},inplace=True)
df.reset_index(inplace=True,drop=True)
regressors = df.columns.drop(['x_date','lag_epm1','epm_date','epm1'])
# -------------------------------- dates index ------------------------------- #
holdout_periods = 12*20 # 20 years used as holdout when using monthly data
test_start_date = '1957-01'
# Create holdout and test index
test_start_idx = df[df['epm_date'] == test_start_date].index[0]
test_end_idx = len(df) - 1
holdout_start_idx = test_start_idx - holdout_periods
holdout_end_idx = holdout_start_idx + holdout_periods - 1
# -------------------------- Lower model predictions ------------------------- #
preds_df = pd.read_csv('./output/lower_preds_df.csv',index_col=0)
preds_df_cols_origin = preds_df.columns.copy()
preds_df.rename(columns = lambda x:re.sub('[^A-Za-z0-9_]+', '', x), inplace=True)
lower_pred_names = preds_df.columns.drop('hist_mean').tolist()

# ---------------------------------------------------------------------------- #
#                              Evaluation metrics                              #
# ---------------------------------------------------------------------------- #
# ---------------------------- Regression metrics ---------------------------- #
def r2_oos_mean(y_true, y_pred, y_mean_pred):
    return 1 - np.sum((y_true - y_pred)**2) / np.sum((y_true-y_mean_pred)**2)

def r2_oos_zero(y_true, y_pred):
    return 1 - np.sum((y_true - y_pred)**2) / np.sum(y_true**2)

r2_oos_zero_score = make_scorer(r2_oos_zero)

# ---------------------------------------------------------------------------- #
#                                  Meta model                                  #
# ---------------------------------------------------------------------------- #
# ----------------------------------- CEnet ---------------------------------- #
regressors12_origin = ['log(DP)', 'log(EP)', 'TMS','BILL','BOND','CREDIT','PPIG','IPG','VOL','MA(1,12)','MA(3,12)','MOM(6)']
regressors12 = [re.sub('[^A-Za-z0-9_]+', '', x) for x in regressors12_origin]
preds_df[regressors12].to_csv('./output/lower_pred_12variables.csv')
# --------------------------- produced by c_enet.R --------------------------- #
os.system("Rscript c_enet.R")
c_enet_pred_df = pd.read_csv('./output/c_enet_pred.csv')
c_enet_pred_df.columns = ['c_enet']
c_enet_pred_df.index = range(test_start_idx, test_end_idx+1)
# ------------------------- Select best lower models ------------------------- #
y_variable = 'epm1'
X_variable_to_choose = lower_pred_names
r2_lower_all_test = [] # each column: all lower models'(except hist_mean) r2
                       # each row: r2 result on the holdout before one test date
for i in tqdm(range(test_end_idx - test_start_idx + 1)):
    idx = {'holdout_idx':np.arange(holdout_start_idx+i, holdout_end_idx+1+i),
           'test_idx':test_start_idx+i}
    r2_lower_one_test = [] # the r2 on the holdout set before one test date
    X_holdout = preds_df.loc[idx['holdout_idx'], X_variable_to_choose]
    y_true_holdout = df.loc[idx['holdout_idx'], y_variable]
    for X_variable in X_variable_to_choose:
        r2_lower_one_test.append(r2_oos_mean(y_true=y_true_holdout,
                                        y_pred=X_holdout[X_variable],
                                        y_mean_pred=preds_df.loc[idx['holdout_idx'],'hist_mean']))
    r2_lower_all_test.append(r2_lower_one_test)

r2_lower_all_test_df = pd.DataFrame(r2_lower_all_test, columns=X_variable_to_choose,
                           index=range(test_start_idx, test_end_idx+1))
# Find the Best lower predictors at each test step
n_best_predictors = 60
X_variable_best = []
for i in r2_lower_all_test_df.index:
    X_variable_best.append(r2_lower_all_test_df.loc[i,:].sort_values()[-n_best_predictors:].index.tolist())
X_variable_best_df = pd.DataFrame(X_variable_best, index=r2_lower_all_test_df.index)
X_variable_best_series = pd.Series(X_variable_best,index=r2_lower_all_test_df.index)
preds_df['combination_best60'] = np.nan
# The mean of 60 models in the first holdout set.
X_variable = X_variable_best_series.loc[test_start_idx]
preds_df.loc[holdout_start_idx:holdout_end_idx,'combination_best60'] = preds_df.loc[holdout_start_idx:holdout_end_idx,X_variable].mean(axis=1)

for i in range(test_end_idx - test_start_idx + 1):
    idx = {'holdout_idx':np.arange(holdout_start_idx+i, holdout_end_idx+1+i),
           'test_idx':test_start_idx+i}
    X_variable = X_variable_best_series.loc[idx['test_idx']]
    preds_df.loc[idx['test_idx'],'combination_best60'] = preds_df.loc[idx['test_idx'],X_variable].mean()
# ---------------------------------------------------------------------------- #
#                                  Meta model                                  #
# ---------------------------------------------------------------------------- #
# ------------------------------------ RF ------------------------------------ #
all_X_variable = lower_pred_names + ['combination_best60']
y_variable = 'epm1'
feature_importance_df = pd.DataFrame(index=all_X_variable)
# Meta model
meta_params = {'max_depth':[1,2,3],
               'min_data_in_leaf': [25,50],
               'feature_fraction_bynode':[0.5],
               'n_estimators': [100],
               'bagging_freq': [20],
               'bagging_fraction':[0.5]}
meta_model = lgb.LGBMRegressor(random_state=random_seed,
                               boosting_type='rf',
                               importance_type='gain')
stacked_pred = []
for i in tqdm(range(test_end_idx - test_start_idx + 1)):
    idx = {'holdout_idx':np.arange(holdout_start_idx+i, holdout_end_idx+1+i),
           'test_idx':test_start_idx+i}
    X_variable = X_variable_best_series.loc[idx['test_idx']] + ['combination_best60']
    X_holdout = preds_df.loc[idx['holdout_idx'], X_variable]
    y_holdout = df.loc[idx['holdout_idx'], y_variable].values
    X_test = preds_df.loc[idx['test_idx'],X_variable].values.reshape(1,-1)
    grid_search = GridSearchCV(meta_model, meta_params, cv=TimeSeriesSplit(2),
                               scoring=r2_oos_zero_score)
    grid_search.fit(X=X_holdout,y=y_holdout)
    stacked_pred.append(grid_search.predict(X_test)[0])
    feature_importance_one_date = pd.DataFrame(grid_search.best_estimator_.feature_importances_,
                                               index=X_variable, columns=[idx['test_idx']])
    feature_importance_df = pd.merge(feature_importance_df, feature_importance_one_date,
                                     how='outer',left_index=True,right_index=True)
######### Collecting results ###########
stacked_pred_df = pd.DataFrame(stacked_pred, index=range(test_start_idx, test_end_idx+1),
                            columns=['stacking_rf'])
stacked_pred_df['hist_mean'] = preds_df.loc[stacked_pred_df.index,'hist_mean']
stacked_pred_df['epm1'] = df.loc[test_start_idx:,'epm1']
stacked_pred_df['epm_date'] = df.loc[test_start_idx:,'epm_date']
stacked_pred_df = stacked_pred_df[['stacking_rf','epm1','hist_mean','epm_date']].copy()

# ------------------------------ Simple average ------------------------------ #
preds_df['simp_mean_all'] = preds_df[lower_pred_names].mean(axis=1)
stacked_pred_df['simp_mean_all'] = preds_df['simp_mean_all'].loc[test_start_idx:].values
regressors2 = [re.sub('[^A-Za-z0-9_]+', '', name) for name in regressors]
stacked_pred_df['scf'] = preds_df[regressors2[0:14]].mean(axis=1).loc[test_start_idx:]
# ------------------------------ Neural networks ----------------------------- #
y_variable = 'epm1'
nn_model = keras.models.Sequential()
nn_model.add(keras.layers.InputLayer(input_shape=[n_best_predictors+1]))
nn_model.add(keras.layers.Dense(16, activation='relu'))
nn_model.add(keras.layers.Dense(8, activation='relu'))
nn_model.add(keras.layers.Dense(4, activation='relu'))
nn_model.add(keras.layers.Dense(1))
nn_model.compile(loss='mse',optimizer='adam')
nn_pred = []
for i in tqdm(range(test_end_idx - test_start_idx + 1)):
    idx = {'holdout_idx':np.arange(holdout_start_idx+i, holdout_end_idx+1+i),
           'test_idx':test_start_idx+i}
    X_variable = X_variable_best_series.loc[idx['test_idx']] + ['combination_best60']
    X_holdout = preds_df.loc[idx['holdout_idx'], X_variable].values
    y_holdout = df.loc[idx['holdout_idx'], y_variable].values
    X_test = preds_df.loc[idx['test_idx']:idx['test_idx'],X_variable].values
    nn_model.fit(X_holdout, y_holdout, epochs=20,verbose=0)
    nn_pred.append(nn_model.predict(X_test)[0][0])
stacked_pred_df['stacking_nn'] = nn_pred
# ----------------------------------- GBRT ----------------------------------- #
meta_model = lgb.LGBMRegressor(bagging_fraction=0.5,
                               random_state=random_seed,
                               boosting_type='gbrt')
gbrt_pred = []
for i in tqdm(range(test_end_idx - test_start_idx + 1)):
    idx = {'holdout_idx':np.arange(holdout_start_idx+i, holdout_end_idx+1+i),
           'test_idx':test_start_idx+i}
    X_variable = X_variable_best_series.loc[idx['test_idx']] + ['combination_best60']
    X_holdout = preds_df.loc[idx['holdout_idx'], X_variable].values
    y_holdout = df.loc[idx['holdout_idx'], y_variable].values
    X_test = preds_df.loc[idx['test_idx']:idx['test_idx'],X_variable].values
    grid_search = GridSearchCV(meta_model, meta_params, cv=TimeSeriesSplit(2),
                               scoring=r2_oos_zero_score)
    grid_search.fit(X=X_holdout,y=y_holdout)
    gbrt_pred.append(grid_search.predict(X_test)[0])
stacked_pred_df['stacking_gbrt'] = gbrt_pred
# ---------------------------------------------------------------------------- #
#                              Collecting results                              #
# ---------------------------------------------------------------------------- #
stacked_pred_df['cenet'] = c_enet_pred_df['c_enet'].values
stacked_pred_df.index.name = 'index'
stacked_pred_df.to_csv('./output/stacked_pred_df.csv')