rm(list=ls())
thisFileDirectory <- function() {
    # https://stackoverflow.com/questions/1815606/determine-path-of-the-executing-script
        cmdArgs <- commandArgs(trailingOnly = FALSE)
        needle <- "--file="
        match <- grep(needle, cmdArgs)
        if (length(match) > 0) {
                # Rscript
            file <- normalizePath(sub(needle, "", cmdArgs[match]))
            file_dir <- substr(file,start=1,stop=tail(unlist(gregexpr('/', file)), n=1))
                return(file_dir)
        } else {
                # 'source'd via R console
            file <- normalizePath(sys.frames()[[1]]$ofile)
            file_dir <- substr(file,start=1,stop=tail(unlist(gregexpr('/', file)), n=1))
                return(file_dir)
        }
}

this_file_dir <- thisFileDirectory()
setwd(this_file_dir)
library(data.table)
library(glmnet)
library(readr)

df <- read_csv('./intermediate/df-enet.csv')
df <- data.table(df)
df[,'index':=0:(nrow(df)-1)]

AICc_relative <- function(model){
    # Not exactly the AICc because the likelihood of the null model is not obtained. But enough for comparison.
    two_likelihood <- model$nulldev - deviance(model)
    k <- model$df
    n <- model$nobs
    AICc <- -two_likelihood + 2*k + 2*k*(k+1) / (n-k-1)
    return(AICc)
}

holdout_periods <- 12*20
test_start_date <- '1957-01'
test_start_idx <- df[epm_date==test_start_date,index]
test_end_idx <- nrow(df)-1
holdout_start_idx <- test_start_idx - holdout_periods
holdout_end_idx <- holdout_start_idx + holdout_periods - 1
# ==========================================================================
# Enet for lower models
# ==========================================================================
X_variable <- c('log(DP)','log(DY)','log(DE)','log(EP)','B/M','TBL','LTY','NTIS','CPIG','LTR','SVAR','DFY','DFR','TMS','BILL','BOND','CREDIT','PPIG','IPG','VOL','MA(1,12)','MA(3,12)','MOM(6)')
enet_pred <- c()

for (idx in holdout_start_idx:test_end_idx) {
    y_train <- df[index %in% 0:(idx-1),epm1]
    X_train <- df[index %in% 0:(idx-1),..X_variable]
    X_pred <- df[index == idx,..X_variable]
    enet <- glmnet(x=as.matrix(X_train), y=y_train, family='gaussian', alpha=0.5)
    aic <- AICc_relative(enet)
    aic_gt0 <- aic[abs(aic)>1e-6] # exclude AIC==0
    aic_idx <- which(aic==min(aic_gt0))[[1]] # adding back the index
    lambda <- enet$lambda[aic_idx]

    enet_pred <- append(enet_pred, predict(enet, newx=as.matrix(X_pred), s=lambda)[[1]])
}

write.csv(enet_pred, './intermediate/enet_pred.csv',row.names=FALSE)