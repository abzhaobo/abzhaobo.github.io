import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression, Lasso, HuberRegressor
from sklearn.base import BaseEstimator, TransformerMixin, RegressorMixin
from sklearn.decomposition import PCA
from sklearn.metrics import mean_squared_error, make_scorer
from sklearn.model_selection import GridSearchCV, TimeSeriesSplit

from statsmodels.nonparametric.kernel_regression import KernelReg

import lightgbm as lgb
from tqdm import tqdm

import tensorflow as tf
from tensorflow import keras

import os
from itertools import combinations, chain
import random
import re


random_seed = 123
os.environ['PYTHONHASHSEED'] = str(random_seed)
os.environ['CUDA_VISIBLE_DEVICES'] = ''
np.random.seed(random_seed)
random.seed(random_seed)
tf.random.set_seed(random_seed)
session_conf = tf.compat.v1.ConfigProto(
    intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
sess = tf.compat.v1.Session(
    graph=tf.compat.v1.get_default_graph(), config=session_conf)
tf.compat.v1.keras.backend.set_session(sess)

path = os.getcwd()
if not os.path.exists(path + '/output'):
    os.makedirs(path + '/output')

# ---------------------------------------------------------------------------- #
#                                  import data                                 #
# ---------------------------------------------------------------------------- #
df = pd.read_excel('./data/epm.xlsx')
regressors = np.array(df.columns[2:]).tolist()
df['epm1'] = df['epm1'].shift(-1)
df['epm_date'] = df['yyyymm'].shift(-1)
df['lag_epm1'] = df['epm1'].shift()
df['infl'] = df['infl'].shift() # inflation is lagging 2 behind epm1.
df['PPIG'] = df['PPIG'].shift()
df.rename(columns={'yyyymm':'x_date'},inplace=True)
df = df[['x_date'] + regressors + ['lag_epm1'] + ['epm_date', 'epm1']].copy()
df.dropna(inplace=True)
df['x_date'] = pd.to_datetime(df['x_date'],format='%Y%m').dt.to_period('M')
df['epm_date'] = pd.to_datetime(df['epm_date'].astype(int), format='%Y%m').dt.to_period('M')
df.rename(columns=dict(zip(df.columns[1:24].tolist(),df.columns[1:24].str.upper())),inplace=True)
df.rename(columns={'LOG(DP)':'log(DP)','LOG(DY)':'log(DY)','LOG(DE)':'log(DE)','LOG(EP)':'log(EP)'},inplace=True)
df.rename(columns={'INFL':'CPIG'},inplace=True)
df.reset_index(inplace=True,drop=True)
regressors = df.columns.drop(['x_date','lag_epm1','epm_date','epm1'])

# ---------------------------------------------------------------------------- #
#                                   Training                                   #
# ---------------------------------------------------------------------------- #
holdout_periods = 12*20 # 20 years used as holdout when using monthly data
test_start_date = '1957-01'

# Create holdout and test index
test_start_idx = df[df['epm_date'] == test_start_date].index[0]
test_end_idx = len(df) - 1
holdout_start_idx = test_start_idx - holdout_periods
holdout_end_idx = holdout_start_idx + holdout_periods - 1
# ------------------------- Kernel with time function ------------------------ #
def standard_normal_pdf(x):
    return np.exp(-x**2 / 2)/np.sqrt(2*np.pi)

class TimeKernelRegressor(BaseEstimator, RegressorMixin):
    def __init__(self, kernel_func=standard_normal_pdf):
        self.kernel_func = kernel_func
    def fit(self, X, y):
        self.X = X
        self.y = y
        return self
    def predict(self, X_pred, tau=1):
        n = len(self.X)
        tau_t = np.arange(1, n+1) / n
        h1 = 1.06 * np.std(tau_t) * n**(-0.2)
        h2 = 1.06 * np.std(self.X) * n**(-0.2)
        numerator = np.sum(self.kernel_func((tau_t[0:n-1] - tau)/h1) * self.kernel_func((self.X[0:n-1] - X_pred)/h2) * self.y[1:n])
        denominator = np.sum(self.kernel_func((tau_t[0:n-1] - tau)/h1) * self.kernel_func((self.X[0:n-1] - X_pred)/h2))
        result = numerator / denominator
        return result

# ------- Linear regression, Huber regression, Weighted least squares, ------- #
# -------------- kernel regression, kernel with time regression -------------- #
preds = [] # all predictions. Rows are predictions on different dates, Columns are different models' predictions
y_variable = 'epm1'
# Lower level models initialization
lower_models = {}
linreg = LinearRegression()
huberreg = HuberRegressor(epsilon=1.05)
# Training and predicting
for idx in tqdm(range(holdout_start_idx, test_end_idx+1)):
    preds_on_idx = [] # All models' predictions on a single date
    y_train = df.loc[:idx-1,y_variable]
    # Linear regression
    for X_variable in regressors:
        X_train = df.loc[:idx-1,[X_variable]].values.reshape(-1,1)
        X_pred = df.loc[idx,[X_variable]].values.reshape(1,-1)
        linreg.fit(X=X_train,y=y_train)
        preds_on_idx.append(linreg.predict(X_pred)[0])
    # Weighted least Squares
        resid = y_train - linreg.predict(X_train)
        weight = 1 / abs(resid)
        preds_on_idx.append(linreg.fit(X=X_train, y=y_train, sample_weight=weight).predict(X_pred)[0])
    # Huber regression
        preds_on_idx.append(huberreg.fit(X=X_train,y=y_train).predict(X_pred)[0])
    # Kernel regression
        X_std = np.std(X_train)
        n = len(X_train)
        h = 1.06*X_std*n**(-0.2)
        preds_on_idx.append(KernelReg(endog=y_train, exog=X_train, var_type='c', reg_type='lc',
                                      bw=[h]).fit(X_pred)[0][0])
    # Kernel with time
        X_train = df.loc[:idx-1,X_variable]
        X_pred = df.loc[idx,X_variable]
        preds_on_idx.append(TimeKernelRegressor().fit(X=X_train,y=y_train).predict(X_pred))
    # Append all models' predictions
    preds.append(preds_on_idx)

# Lower model prediction results
preds_df = pd.DataFrame(preds, index=range(holdout_start_idx, test_end_idx+1),
                        columns=list(chain(*list(zip(regressors,
                                                     [reg+'_wls' for reg in regressors],
                                                     [reg+'_huber' for reg in regressors],
                                                     [reg+'_kernel' for reg in regressors],
                                                     [reg+'_kernel_time' for reg in regressors]
                                                    ))))
                       )
# ----------------------------------- Enet ----------------------------------- #
# Enet is produced by enet.R
df.to_csv('./output/df-enet.csv',index=False)
os.system("Rscript enet.R")
enet_pred_df = pd.read_csv('./output/enet_pred.csv')
# ------------------------------------ MMA ----------------------------------- #
# mma is produced by mma.R
os.system("Rscript mma.R")
mma_pred_df = pd.read_csv('./output/mma_pred.csv')
mma_pred_df.columns=['mma']
# ----------------------------------- LASSO ---------------------------------- #
# lasso is produced by lasso.R
os.system("Rscript lasso.R")
lasso_pred_df = pd.read_csv('./output/lasso_pred.csv')
lasso_pred_df.columns=['lasso']
# ------------------------------------ CSR ----------------------------------- #
# Same as Elliott et al. (2013). ik is not available
X_csr = ['log(DP)','log(DY)','log(EP)','B/M','NTIS','TBL','LTR','TMS','DFY','DFR','CPIG']
def complete_subset_reg(X_train, y_train, X_pred, k):
    """
    k: number of X to be selected
    """
    ncol_X = X_train.shape[1]
    complt_subset = combinations(range(ncol_X), k)
    y_pred = []
    for i in complt_subset: # each i is a combination index
        i = list(i)
        y_pred.append(LinearRegression().fit(X=X_train.iloc[:,i],y=y_train).predict(X_pred.iloc[:,i]))
    return np.mean(y_pred)

csr_pred = []
k = 3
for idx in tqdm(range(holdout_start_idx, test_end_idx+1)):
    X_train = df.loc[:idx-1, X_csr]
    y_train = df.loc[:idx-1, 'epm1']
    X_pred = df.loc[idx:idx, X_csr]
    csr_pred.append(complete_subset_reg(X_train=X_train, y_train=y_train, X_pred=X_pred, k=k))

csr_pred_df = pd.DataFrame(csr_pred)
csr_pred_df.columns = ['k=3']

# ------------------------------------ PCA ----------------------------------- #
class PCARegressor(BaseEstimator, RegressorMixin):
    def __init__(self, n_components=3):
        self.n_components = n_components

    def fit(self, X, y):
        self.pca_ = PCA(n_components=self.n_components).fit(X)
        self.X_ = self.pca_.transform(X)
        self.reg_ = LinearRegression().fit(self.X_,y)
        return self

    def predict(self, X):
        self.pred_ = self.reg_.predict(self.pca_.transform(X))
        return self.pred_

pca_pred = []
y_variable = 'epm1'
X_variable = regressors
pca = PCARegressor(n_components=0.8)
for idx in tqdm(range(holdout_start_idx, test_end_idx+1)):
    y_train = df.loc[:idx-1,y_variable]
    X_train = df.loc[:idx-1,X_variable]
    X_pred = df.loc[idx:idx,X_variable]
    pca_pred.append(pca.fit(X_train, y_train).predict(X_pred)[0])

pca_pred_df = pd.DataFrame(pca_pred, columns=['pca'])

# ------------------------------ Neural networks ----------------------------- #
nn_model = keras.models.Sequential()
nn_model.add(keras.layers.InputLayer(input_shape=[X_train.shape[1]]))
nn_model.add(keras.layers.Dense(8, activation='relu'))
nn_model.add(keras.layers.Dense(4, activation='relu'))
nn_model.add(keras.layers.Dense(1))
nn_model.compile(loss='mse',optimizer='adam')
nn_pred = []
y_variable = 'epm1'
X_variable = regressors
for idx in tqdm(range(holdout_start_idx, test_end_idx+1)):
    y_train = df.loc[:idx-1,y_variable]
    X_train = df.loc[:idx-1,X_variable]
    X_pred = df.loc[idx:idx,X_variable]
    nn_model.fit(X_train, y_train, epochs=30,verbose=0)
    nn_pred.append(nn_model.predict(X_pred)[0][0])

nn_pred_df = pd.DataFrame(nn_pred,columns=['2_hidden_layer'])

# ---------------- Kitchen-sink OLS, RF, GBRT, Historical Mean --------------- #
# lightgbm cannot accept column names with special characters.
regressors_origin = regressors.copy()
regressors = [re.sub('[^A-Za-z0-9_]+', '', x) for x in regressors_origin]
df_cols_origin = df.columns.copy()
df.rename(columns = lambda x:re.sub('[^A-Za-z0-9_]+', '', x), inplace=True)

preds2 = [] # all predictions. Rows are predictions on different dates, Columns are different models' predictions
y_variable = 'epm1'
# Lower level models initialization
lower_models = {}
lower_models['kitchen'] = LinearRegression()
rf_params = {'max_depth':3, 'min_data_in_leaf': 25,
             'bagging_freq': 20,'bagging_fraction': 0.5,
            'feature_fraction_bynode':0.5}
lower_models['rf'] = lgb.LGBMRegressor(boosting_type='rf',random_state=random_seed,
                                       objective='huber',**rf_params,
                                       verbose= -1)
lower_models['gbrt'] = lgb.LGBMRegressor(random_state=random_seed,
                                         **rf_params,
                                         objective='huber',
                                         verbose= -1)

# Training and predicting
for idx in tqdm(range(holdout_start_idx, test_end_idx+1)):
    preds2_on_idx = [] # All models' predictions on a single date
    y_train = df.loc[:idx-1,y_variable]
    X_variable = regressors
    X_train = df.loc[:idx-1,X_variable]
    X_pred = df.loc[idx:idx,X_variable]
    # kitchen sink OLS
    preds2_on_idx.append(lower_models['kitchen'].fit(X=X_train, y=y_train).predict(X_pred)[0])
    # Random forest
    rf_lower = lower_models['rf'].fit(X=X_train,y=y_train)
    preds2_on_idx.append(rf_lower.predict(X_pred)[0])
    # Gradient Boosted Regression Trees
    preds2_on_idx.append(lower_models['gbrt'].fit(X=X_train,y=y_train).predict(X_pred)[0])
    # Historical mean
    preds2_on_idx.append(df.loc[:idx,'lag_epm1'].mean())
    # Append all models' predictions
    preds2.append(preds2_on_idx)

preds_df2 = pd.DataFrame(preds2, columns=['kitchen','rf','gbrt','hist_mean'],index=range(holdout_start_idx,test_end_idx+1))
# ---------------------------------------------------------------------------- #
#                              Combine all results                             #
# ---------------------------------------------------------------------------- #
preds_df['enet'] = enet_pred_df['x'].values
preds_df['mma'] = mma_pred_df['mma'].values
preds_df['csr'] = csr_pred_df['k=3'].values
preds_df['lasso'] = lasso_pred_df['lasso'].values
preds_df['pca'] = pca_pred_df['pca'].values
preds_df['nn'] = nn_pred_df['2_hidden_layer'].values
preds_df = pd.merge(preds_df,preds_df2,left_index=True,right_index=True)
preds_df.index.name = 'index'
preds_df.to_csv('./output/lower_preds_df.csv')