Steps for running the sample code:
1. run lower_models.py
2. run meta_models.py

The "lower_preds_df.csv" collects the lower model predictions, the "stacked_pred_df.csv" collects the meta model predictions and benchmark data.

Please cite the paper:
Zhao, A. B., and T. Cheng. 2022. Stock Return Prediction: Stacking a Variety of Models. Journal of Empirical Finance 67:288–317.


Copyright 2022 Albert Bo Zhao