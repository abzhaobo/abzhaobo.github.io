# ==========================================================================
# Performs Mallows' Model Averaging as of Hansen (2007)
# Requires MAMI package in R
# ==========================================================================
rm(list=ls())
library(data.table)
library(MAMI)
library(readr)

df <- read_csv('./intermediate/df-enet.csv')
df <- data.table(df)
df[,'index':=0:(nrow(df)-1)]

holdout_periods <- 12*20
test_start_date <- '1957-01'
test_start_idx <- df[epm_date==test_start_date,index]
test_end_idx <- nrow(df)-1
holdout_start_idx <- test_start_idx - holdout_periods
holdout_end_idx <- holdout_start_idx + holdout_periods - 1

setnames(df, c('log(DP)','log(DY)','log(DE)','log(EP)','B/M','MA(1,12)','MA(3,12)','MOM(6)'),
    c('logDP','logDY','logDE','logEP','BM','MA112','MA312','MOM6'))

# ==========================================================================
# MMA
# ==========================================================================
X_variable <- c('BM','TBL','LTY','NTIS','CPIG','LTR','SVAR','DFY','DFR','TMS','BILL','BOND','CREDIT','PPIG','IPG','VOL','MA112','MA312','MOM6','logDP','logDY','logDE','logEP')
mma_pred <- c()

for (idx in holdout_start_idx:test_end_idx){
    y_train <- df[index %in% 0:(idx-1),epm1]
    X_train <- df[index %in% 0:(idx-1),..X_variable]
    X_pred <- df[index == idx,..X_variable]

    m1 <- jma(y=y_train, x=X_train, ma.method='MMA')
    mma_pred <- append(mma_pred,predict(m1, newdata=X_pred)[1])
}
write.csv(mma_pred, './intermediate/mma_pred.csv',row.names=FALSE)