#!/usr/bin/env python3

a = 'Hello world!'
print(a)