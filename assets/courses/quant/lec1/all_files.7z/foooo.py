# -*- coding: utf-8 -*-
def my_foo(n):
    if n < 10:
        return n
    else:
        return -n
