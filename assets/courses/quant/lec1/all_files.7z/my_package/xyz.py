#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"An example of module"

def my_print():
    print(' Roses are red,\n',
          'Violets are blue,\n',
          'Whatever you say,\n',
          'is always true.')


if __name__ == '__main__':
    my_print()
